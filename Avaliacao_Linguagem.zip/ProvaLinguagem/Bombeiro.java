import java.util.Scanner;

public class Bombeiro {
    public static void main(String[] args) {
        
        while(true){
            
			Scanner sc = new Scanner(System.in);

			Incendio i = new Incendio();
			
            System.out.println("Onde esta acontecendo o incendio?");
            i.local = sc.nextLine();
			
			System.out.println("Qual o tipo de incendio? A - Materiais solidos  B - Liquidos Inflamaveis   C - Materiais eletricos energizados");
            i.tipo = sc.nextLine();
			
			
			Extintor exa = new Extintor();
			exa.tipo = "A";
			exa.combater(i);
			
			
			Extintor exb = new Extintor();
			exb.tipo = "Espuma";
			exb.combater(i);
			
			Extintor exc = new Extintor();
			exc.tipo = "CO2";
			exc.combater(i);
			
			System.out.println("Fim da acao dos bombeiros.");
        }
    }
}